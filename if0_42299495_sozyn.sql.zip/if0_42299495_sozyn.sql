-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql112.infinityfree.com
-- Generation Time: Sep 30, 2026 at 01:55 AM
-- Server version: 11.4.13-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_42299495_sozyn`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`id`, `username`, `password_hash`, `created_at`) VALUES
(1, 'shahidanmo', '$2y$12$24809JtWk0X5KyQDZKHva.f68eQkTtP7sqeG3d5gBFgMJWsl5AXPO', '2026-09-26 08:29:03');

-- --------------------------------------------------------

--
-- Table structure for table `newsletter_log`
--

CREATE TABLE `newsletter_log` (
  `id` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `audience` varchar(50) NOT NULL,
  `total_sent` int(11) NOT NULL DEFAULT 0,
  `total_failed` int(11) NOT NULL DEFAULT 0,
  `admin_username` varchar(100) DEFAULT NULL,
  `sent_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `newsletter_log`
--

INSERT INTO `newsletter_log` (`id`, `subject`, `audience`, `total_sent`, `total_failed`, `admin_username`, `sent_at`) VALUES
(1, 'SOZYN Newsletter - September 2026', 'all', 1, 0, 'shahidanmo', '2026-09-29 05:49:43'),
(2, 'SOZYN Newsletter - September 2026', 'all', 1, 0, 'shahidanmo', '2026-09-29 05:57:02'),
(3, 'SOZYN Newsletter - September 2026', 'all', 1, 0, 'shahidanmo', '2026-09-29 11:24:04'),
(4, 'SOZYN Newsletter - September 2026', 'all', 2, 0, 'shahidanmo', '2026-09-29 12:33:23');

-- --------------------------------------------------------

--
-- Table structure for table `subscribers`
--

CREATE TABLE `subscribers` (
  `id` int(11) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `email` varchar(190) NOT NULL,
  `gender` enum('male','female','other','prefer_not_to_say') NOT NULL DEFAULT 'prefer_not_to_say',
  `subscriber_type` enum('jobseeker','organization') NOT NULL,
  `designation` varchar(150) DEFAULT NULL,
  `status` enum('active','unsubscribed') NOT NULL DEFAULT 'active',
  `welcome_sent` tinyint(1) NOT NULL DEFAULT 0,
  `unsubscribe_token` varchar(64) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subscribers`
--

INSERT INTO `subscribers` (`id`, `full_name`, `email`, `gender`, `subscriber_type`, `designation`, `status`, `welcome_sent`, `unsubscribe_token`, `created_at`, `updated_at`) VALUES
(4, 'Shaik Karishma', 'anmosht@gmail.com', 'female', 'jobseeker', '', 'active', 1, '7bde7bcda1e8b6cf3d856b42d7e9dc5fb8af78cad377d758', '2026-09-30 05:48:38', '2026-09-30 05:49:54'),
(5, 'Andlagutti Mohammad SHahid', 'anmoshahid@gmail.com', 'male', 'organization', 'Director', 'active', 0, '38f80503975b828429f824ab512c710b9f33fc7a5bf83ade', '2026-09-30 05:49:04', '2026-09-30 05:49:04'),
(6, 'Andlagutti Samiyah Aziza', 'mysozyn@gmail.com', 'female', 'jobseeker', 'Doctor', 'active', 1, '0dbc0c7e0d00c446742776eab657b93c104c612a97e0496c', '2026-09-30 05:49:30', '2026-09-30 05:50:01');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_users`
--
ALTER TABLE `admin_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `newsletter_log`
--
ALTER TABLE `newsletter_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscribers`
--
ALTER TABLE `subscribers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `unsubscribe_token` (`unsubscribe_token`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_users`
--
ALTER TABLE `admin_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `newsletter_log`
--
ALTER TABLE `newsletter_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `subscribers`
--
ALTER TABLE `subscribers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

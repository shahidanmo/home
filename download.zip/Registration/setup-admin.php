<?php
// ONE-TIME USE: creates (or resets) the first admin account for the live
// content editor. Visit this page once, create your account, then DELETE
// this file from the server. It refuses to run if an admin already exists,
// so it can't be used to hijack the account later even if left in place —
// but delete it anyway.

require_once 'data/db_connection.php';

$error = '';
$done = false;

$existing = $conn->query("SELECT COUNT(*) AS c FROM admin_users")->fetch_assoc();
$hasAdmin = $existing && (int)$existing['c'] > 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$hasAdmin) {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm'] ?? '';

    if ($username === '' || strlen($username) < 3) {
        $error = 'Username must be at least 3 characters.';
    } elseif (strlen($password) < 10) {
        $error = 'Password must be at least 10 characters.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO admin_users (username, password_hash) VALUES (?, ?)");
        $stmt->bind_param("ss", $username, $hash);
        if ($stmt->execute()) {
            $done = true;
        } else {
            $error = 'Could not create account. It may already exist.';
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>SOZYN Admin Setup</title>
<style>
body { font-family: -apple-system, Segoe UI, Arial, sans-serif; background:#0f1720; color:#e6ebf1; display:flex; align-items:center; justify-content:center; min-height:100vh; margin:0; }
.card { background:#1c2430; padding:36px; border-radius:12px; width:100%; max-width:380px; box-shadow:0 20px 50px rgba(0,0,0,.4); }
h1 { font-size:1.3rem; margin-top:0; }
label { display:block; margin:14px 0 6px; font-size:.85rem; color:#aab3c0; }
input { width:100%; box-sizing:border-box; padding:10px 12px; border-radius:6px; border:1px solid #333f4f; background:#0f1720; color:#fff; font-size:.95rem; }
button { margin-top:22px; width:100%; padding:12px; border:none; border-radius:6px; background:#6366f1; color:#fff; font-weight:600; cursor:pointer; font-size:.95rem; }
.error { background:#3a1f24; color:#ff9aa2; padding:10px 12px; border-radius:6px; font-size:.85rem; margin-top:14px; }
.done { background:#1a3324; color:#8ff0b0; padding:14px; border-radius:6px; font-size:.9rem; }
.warn { font-size:.78rem; color:#f5c96b; margin-top:18px; line-height:1.5; }
</style>
</head>
<body>
<div class="card">
<h1>SOZYN — Admin Setup</h1>
<?php if ($hasAdmin && !$done): ?>
    <p>An admin account already exists. This setup page is now disabled.</p>
    <p class="warn">Delete <code>Registration/setup-admin.php</code> from the server if you haven't already.</p>
    <p><a href="/Registration/Admin.php" style="color:#8bb4ff;">Go to admin login →</a></p>
<?php elseif ($done): ?>
    <div class="done">Admin account created. You can now log in.</div>
    <p class="warn">Important: delete <code>Registration/setup-admin.php</code> from the server now — leave it there and it becomes a stale file an attacker could probe, even though it refuses to create a second account.</p>
    <p style="margin-top:16px;"><a href="/Registration/Admin.php" style="color:#8bb4ff;">Go to admin login →</a></p>
<?php else: ?>
    <form method="POST">
        <label>Username</label>
        <input type="text" name="username" required minlength="3">
        <label>Password (min 10 characters)</label>
        <input type="password" name="password" required minlength="10">
        <label>Confirm password</label>
        <input type="password" name="confirm" required minlength="10">
        <?php if ($error): ?><div class="error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
        <button type="submit">Create admin account</button>
    </form>
<?php endif; ?>
</div>
</body>
</html>

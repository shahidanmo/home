-- SOZYN admin login: only table needed now that site content lives in
-- Registration/data/site-content.json instead of the database.
--
-- If you already ran the earlier version of this file and created
-- site_content / site_meta / content_changelog, they're no longer used by
-- anything and are safe to drop:
--
--   DROP TABLE IF EXISTS site_content;
--   DROP TABLE IF EXISTS site_meta;
--   DROP TABLE IF EXISTS content_changelog;

CREATE TABLE IF NOT EXISTS `admin_users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(100) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

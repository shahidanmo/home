<?php
// Reuses the single set of DB credentials already defined at /data/db_connection.php
// so there is only one place to update credentials if they ever change/rotate.
require_once __DIR__ . '/../../data/db_connection.php';

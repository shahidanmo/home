-- Run this once in phpMyAdmin — adds tracking for which subscribers have
-- already received a welcome letter, so the admin dashboard can flag the
-- ones still pending.
ALTER TABLE `subscribers`
  ADD COLUMN `welcome_sent` TINYINT(1) NOT NULL DEFAULT 0 AFTER `status`;

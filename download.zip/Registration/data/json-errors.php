<?php
// Turns PHP errors/exceptions into readable JSON so the admin pages can show
// the real problem instead of "Unexpected token '<'".
ini_set('display_errors', '0');
error_reporting(E_ALL);

function sozyn_json_fail(string $message): void
{
    if (!headers_sent()) {
        http_response_code(500);
        header('Content-Type: application/json');
    }
    echo json_encode(['success' => false, 'error' => $message]);
}

set_exception_handler(function ($e) {
    sozyn_json_fail('Server error: ' . $e->getMessage());
    exit;
});

register_shutdown_function(function () {
    $err = error_get_last();
    if ($err && in_array($err['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
        sozyn_json_fail('Fatal error: ' . $err['message'] . ' (' . basename($err['file']) . ':' . $err['line'] . ')');
    }
});

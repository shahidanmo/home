<?php
// Public. Reached from the unsubscribe link in every newsletter footer.
require_once 'db_connection.php';

$token = trim($_GET['token'] ?? '');
$status = 'invalid';

if ($token !== '') {
    $stmt = $conn->prepare("SELECT id, full_name, status FROM subscribers WHERE unsubscribe_token = ?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($row) {
        if ($row['status'] === 'unsubscribed') {
            $status = 'already';
        } else {
            $update = $conn->prepare("UPDATE subscribers SET status='unsubscribed' WHERE id=?");
            $update->bind_param("i", $row['id']);
            $update->execute();
            $update->close();
            $status = 'done';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Unsubscribe — SOZYN</title>
<style>
body { font-family: -apple-system, Segoe UI, Arial, sans-serif; background:#f5f6f8; display:flex; align-items:center; justify-content:center; min-height:100vh; margin:0; }
.card { background:#fff; padding:36px; border-radius:12px; max-width:420px; text-align:center; box-shadow:0 10px 30px rgba(0,0,0,.08); }
h1 { font-size:1.3rem; color:#26313d; }
p { color:#555; line-height:1.6; }
a { color:#6366f1; }
</style>
</head>
<body>
<div class="card">
<?php if ($status === 'done'): ?>
    <h1>You've been unsubscribed</h1>
    <p>You won't receive any more newsletters from SOZYN. You can resubscribe any time from our homepage.</p>
<?php elseif ($status === 'already'): ?>
    <h1>Already unsubscribed</h1>
    <p>This email was already off our newsletter list.</p>
<?php else: ?>
    <h1>Link not recognized</h1>
    <p>This unsubscribe link is invalid or has expired.</p>
<?php endif; ?>
    <p><a href="/">Return to sozyn.co.in</a></p>
</div>
</body>
</html>

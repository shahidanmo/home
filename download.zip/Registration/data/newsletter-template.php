<?php
// Wraps an admin-uploaded HTML newsletter body with a personalized greeting
// and a standard SOZYN footer + unsubscribe link.

function sozyn_build_newsletter_html(string $bodyHtml, string $recipientName, string $unsubscribeUrl): string
{
    $safeName = htmlspecialchars($recipientName, ENT_QUOTES);
    // Let admins also drop {{name}} anywhere inside their own HTML.
    $bodyHtml = str_replace('{{name}}', $safeName, $bodyHtml);

    return '
<!DOCTYPE html>
<html>
<body style="margin:0; padding:0; background:#f5f6f8; font-family:Arial, Helvetica, sans-serif;">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f5f6f8; padding:24px 0;">
<tr><td align="center">
<table role="presentation" width="600" cellpadding="0" cellspacing="0" style="background:#ffffff; border-radius:10px; overflow:hidden;">
<tr><td style="padding:28px 32px 0 32px; font-size:15px; color:#26313d;">
    Hi ' . $safeName . ',
</td></tr>
<tr><td style="padding:16px 32px 28px 32px; font-size:15px; color:#26313d; line-height:1.6;">
    ' . $bodyHtml . '
</td></tr>
<tr><td style="background:#1c2430; color:#aab3c0; padding:26px 32px; font-size:12px; line-height:1.7; text-align:center;">
    <img src="https://sozyn.co.in/images/sozyn-logo.svg" alt="SOZYN" style="height:30px; width:auto; display:inline-block;">
    <div style="margin-top:8px;">Connecting Talent. Creating Opportunities.</div>
    <div style="margin-top:14px;">&copy; ' . date('Y') . ' SOZYN. All rights reserved.</div>
    <div style="margin-top:8px;">
        <a href="https://sozyn.co.in" style="color:#8bb4ff; text-decoration:none;">Website</a>
        &nbsp;|&nbsp;
        <a href="mailto:info@sozyn.co.in" style="color:#8bb4ff; text-decoration:none;">Contact Us</a>
        &nbsp;|&nbsp;
        <a href="' . htmlspecialchars($unsubscribeUrl, ENT_QUOTES) . '" style="color:#8bb4ff; text-decoration:none;">Unsubscribe</a>
    </div>
</td></tr>
</table>
</td></tr>
</table>
</body>
</html>';
}

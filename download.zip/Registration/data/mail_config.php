<?php
// Single source of truth for SMTP credentials, so send-verification.php and
// the newsletter sender don't each hardcode their own copy. These are the
// same credentials already used in send-verification.php.
//
// TODO (security): move these into environment variables or a file outside
// the web root once you rotate the password (see README security notes).

return [
    'host' => 'smtpout.secureserver.net',
    'username' => 'info@sozyn.co.in',
    'password' => 'Howdy@123',
    'port' => 465,
    'encryption' => 'smtps', // maps to PHPMailer::ENCRYPTION_SMTPS
    'from_email' => 'support@sozyn.co.in',
    'from_name' => 'SOZYN Services',
];

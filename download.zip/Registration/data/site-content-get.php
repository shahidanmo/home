<?php
// Public, read-only. index.html fetches this on every load to populate
// data-key / data-key-html / data-href-key elements. Content lives in a
// flat JSON file rather than the database.

header('Content-Type: application/json');

$file = __DIR__ . '/site-content.json';

if (!file_exists($file)) {
    echo json_encode(['success' => true, 'values' => new stdClass(), 'nav' => [], 'meta' => ['last_updated' => null, 'changelog' => []]]);
    exit;
}

$raw = file_get_contents($file);
$store = json_decode($raw, true);

if (!is_array($store)) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Content file is corrupted.']);
    exit;
}

$values = $store['values'] ?? [];
$meta = $store['meta'] ?? ['last_updated' => null, 'changelog' => []];

echo json_encode([
    'success' => true,
    'values' => $values,
    // Nav stays static in index.html for now — not managed by the editor yet.
    'nav' => [],
    'meta' => $meta,
]);

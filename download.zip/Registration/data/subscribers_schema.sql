-- Subscriber list + newsletter send history.
-- Run this once in phpMyAdmin (same database as admin_users).

CREATE TABLE IF NOT EXISTS `subscribers` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `full_name` VARCHAR(150) NOT NULL,
  `email` VARCHAR(190) NOT NULL UNIQUE,
  `gender` ENUM('male','female','other','prefer_not_to_say') NOT NULL DEFAULT 'prefer_not_to_say',
  `subscriber_type` ENUM('jobseeker','organization') NOT NULL,
  `designation` VARCHAR(150) DEFAULT NULL,
  `status` ENUM('active','unsubscribed') NOT NULL DEFAULT 'active',
  `welcome_sent` TINYINT(1) NOT NULL DEFAULT 0,
  `unsubscribe_token` VARCHAR(64) NOT NULL UNIQUE,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `newsletter_log` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `subject` VARCHAR(255) NOT NULL,
  `audience` VARCHAR(50) NOT NULL,
  `total_sent` INT NOT NULL DEFAULT 0,
  `total_failed` INT NOT NULL DEFAULT 0,
  `admin_username` VARCHAR(100),
  `sent_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

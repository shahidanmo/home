<?php
// Admin-only. Sends the "Thanks for subscribing" letter to a specific list
// of subscriber IDs (either hand-picked, or every currently-pending one),
// in small batches, and marks each as welcome_sent=1 once delivered.

require_once __DIR__ . '/json-errors.php';
require_once 'admin-auth.php';
sozyn_require_admin();

header('Content-Type: application/json');
require_once 'db_connection.php';
require_once 'mailer.php';
require_once 'newsletter-template.php';
require_once 'welcome-email.php';

const BATCH_SIZE = 12;

$raw = file_get_contents('php://input');
$body = json_decode($raw, true);

$ids = isset($body['ids']) && is_array($body['ids']) ? array_map('intval', $body['ids']) : [];
$offset = isset($body['offset']) ? max(0, (int)$body['offset']) : 0;

if (empty($ids)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'No subscriber IDs provided.']);
    exit;
}

$total = count($ids);
$batchIds = array_slice($ids, $offset, BATCH_SIZE);

$sentThisBatch = 0;
$failedThisBatch = 0;

if (!empty($batchIds)) {
    $placeholders = implode(',', array_fill(0, count($batchIds), '?'));
    $types = str_repeat('i', count($batchIds));
    $stmt = $conn->prepare("SELECT id, full_name, email, subscriber_type, unsubscribe_token FROM subscribers WHERE id IN ($placeholders)");
    $stmt->bind_param($types, ...$batchIds);
    $stmt->execute();
    $result = $stmt->get_result();

    $updateStmt = $conn->prepare("UPDATE subscribers SET welcome_sent = 1 WHERE id = ?");

    while ($row = $result->fetch_assoc()) {
        try {
            $mail = sozyn_new_mailer();
            $mail->addAddress($row['email'], $row['full_name']);
            $mail->Subject = sozyn_welcome_subject($row['subscriber_type']);
            $unsubUrl = 'https://sozyn.co.in/unsubscribe?token=' . urlencode($row['unsubscribe_token']);
            $mail->Body = sozyn_build_newsletter_html(sozyn_welcome_body_html($row['subscriber_type']), $row['full_name'], $unsubUrl);
            $mail->send();
            $updateStmt->bind_param("i", $row['id']);
            $updateStmt->execute();
            $sentThisBatch++;
        } catch (Exception $e) {
            $failedThisBatch++;
            @file_put_contents(
                __DIR__ . '/mail-errors.log',
                '[' . date('c') . '] welcome letter to ' . $row['email'] . ' failed: ' . $e->getMessage() . "\n",
                FILE_APPEND
            );
        }
    }
    $stmt->close();
    $updateStmt->close();
}

$newOffset = $offset + BATCH_SIZE;
$done = $newOffset >= $total;

echo json_encode([
    'success' => true,
    'sent_this_batch' => $sentThisBatch,
    'failed_this_batch' => $failedThisBatch,
    'offset' => $newOffset,
    'total' => $total,
    'done' => $done,
]);

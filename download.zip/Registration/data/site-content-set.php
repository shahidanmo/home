<?php
// Admin-only. Saves the pending edits made in the live editor overlay into
// a flat JSON file (no database involved).

require_once 'admin-auth.php';
sozyn_require_admin();

header('Content-Type: application/json');

$file = __DIR__ . '/site-content.json';

$raw = file_get_contents('php://input');
$body = json_decode($raw, true);

if (!is_array($body) || empty($body['changes']) || !is_array($body['changes'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'No changes provided.']);
    exit;
}

$note = isset($body['note']) ? trim((string)$body['note']) : '';
// A sane cap so a malformed request can't write an enormous file.
$changes = array_slice($body['changes'], 0, 300, true);

// Open (creating if needed) and lock the file for the whole read-modify-write
// so two saves in quick succession can't clobber each other.
$handle = fopen($file, file_exists($file) ? 'r+' : 'w+');
if (!$handle) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Could not open content file. Check that Registration/data/ is writable by the web server.']);
    exit;
}

if (!flock($handle, LOCK_EX)) {
    fclose($handle);
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Could not lock content file for writing.']);
    exit;
}

$size = filesize($file);
$raw = $size > 0 ? fread($handle, $size) : '';
$store = $raw !== '' ? json_decode($raw, true) : null;
if (!is_array($store)) {
    $store = ['values' => [], 'meta' => ['last_updated' => null, 'changelog' => []]];
}
if (!isset($store['values']) || !is_array($store['values'])) { $store['values'] = []; }
if (!isset($store['meta']) || !is_array($store['meta'])) { $store['meta'] = ['last_updated' => null, 'changelog' => []]; }
if (!isset($store['meta']['changelog']) || !is_array($store['meta']['changelog'])) { $store['meta']['changelog'] = []; }

$saved = 0;
foreach ($changes as $key => $value) {
    $key = (string)$key;
    if ($key === '' || strlen($key) > 150) { continue; }
    $store['values'][$key] = is_string($value) ? $value : json_encode($value);
    $saved++;
}

if ($saved > 0) {
    $now = date('c');
    $store['meta']['last_updated'] = $now;
    $store['meta']['changelog'][] = [
        'date' => $now,
        'notes' => $note !== '' ? [$note] : [$saved . ' item(s) updated'],
    ];
    // Keep the changelog from growing forever.
    if (count($store['meta']['changelog']) > 50) {
        $store['meta']['changelog'] = array_slice($store['meta']['changelog'], -50);
    }
}

$json = json_encode($store, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

ftruncate($handle, 0);
rewind($handle);
$writeOk = fwrite($handle, $json) !== false;
fflush($handle);
flock($handle, LOCK_UN);
fclose($handle);

if (!$writeOk) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to write content file.']);
    exit;
}

echo json_encode(['success' => true, 'saved' => $saved]);

<?php
// Admin-only. Delete / unsubscribe / resubscribe a single subscriber row.
require_once 'admin-auth.php';
sozyn_require_admin();

header('Content-Type: application/json');
require_once 'db_connection.php';

$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
$action = trim($_POST['action'] ?? '');

if ($id <= 0 || !in_array($action, ['delete', 'unsubscribe', 'resubscribe'], true)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid request.']);
    exit;
}

if ($action === 'delete') {
    $stmt = $conn->prepare("DELETE FROM subscribers WHERE id = ?");
} elseif ($action === 'unsubscribe') {
    $stmt = $conn->prepare("UPDATE subscribers SET status='unsubscribed' WHERE id = ?");
} else {
    $stmt = $conn->prepare("UPDATE subscribers SET status='active' WHERE id = ?");
}
$stmt->bind_param("i", $id);
$ok = $stmt->execute();
$stmt->close();

echo json_encode(['success' => $ok]);

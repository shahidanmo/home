<?php
// Content for the automatic "welcome / how it works / pricing" email sent
// the moment someone subscribes, tailored to jobseeker vs organization.
// Reuses sozyn_build_newsletter_html() for the shared greeting + SOZYN footer.

function sozyn_welcome_subject(string $type): string
{
    return 'Thanks for subscribing to SOZYN Newsletter!';
}

function sozyn_welcome_body_html(string $type): string
{
    $btn = function (string $text, string $href): string {
        return '<div style="text-align:center; margin:24px 0;">'
            . '<a href="' . htmlspecialchars($href, ENT_QUOTES) . '" style="background:#6366f1; color:#ffffff; '
            . 'text-decoration:none; padding:13px 30px; border-radius:6px; font-family:\'Segoe UI\',Arial,sans-serif; '
            . 'font-weight:700; font-size:14px; display:inline-block;">' . htmlspecialchars($text, ENT_QUOTES) . '</a></div>';
    };

    if ($type === 'organization') {
        return '
            <h2 style="font-family:\'Segoe UI\',Arial,sans-serif; color:#1c2430; font-size:20px; margin:0 0 14px;">Thanks for subscribing to SOZYN Newsletter!</h2>
            <p style="font-family:\'Segoe UI\',Arial,sans-serif; font-size:15px; color:#33404d; line-height:1.6;">
                Here is a bit more about what\'s waiting for you in the <strong>SOZYN Employer Suite</strong>.
            </p>
            <p style="font-family:\'Segoe UI\',Arial,sans-serif; font-size:15px; color:#33404d; line-height:1.6;">
                Once you register, you can:
            </p>
            <ul style="font-family:\'Segoe UI\',Arial,sans-serif; font-size:14px; color:#33404d; line-height:1.8;">
                <li>Manage your employees and verify candidates</li>
                <li>Post jobs and schedule interviews via <strong>WyND</strong></li>
                <li>Verify candidature and onboard hires — all in one place</li>
            </ul>
            <div style="background:#f0f1fb; border-left:4px solid #6366f1; padding:16px 20px; border-radius:6px; margin:18px 0; font-family:\'Segoe UI\',Arial,sans-serif; font-size:14px; color:#33404d; line-height:1.7;">
                <strong>Pricing at a glance</strong><br>
                Registration: ₹299 + GST, one-time — includes 5 free WyND job posts (valid 90 days)<br>
                Additional job posts: ₹99 + GST per post after your 5 free posts<br>
                Past employee verification data: ₹199 per 100 records, or ₹399 for the full dataset (30-day access)
            </div>
            <p style="font-family:\'Segoe UI\',Arial,sans-serif; font-size:13px; color:#7d8896; line-height:1.6;">
                Full pricing details and terms are always available at sozyn.co.in.
            </p>
            ' . $btn('Register Your Organization', 'https://sozyn.co.in/register?tab=employer');
    }

    return '
        <h2 style="font-family:\'Segoe UI\',Arial,sans-serif; color:#1c2430; font-size:20px; margin:0 0 14px;">Thanks for subscribing to SOZYN Newsletter!</h2>
        <p style="font-family:\'Segoe UI\',Arial,sans-serif; font-size:15px; color:#33404d; line-height:1.6;">
            Here is a bit more about what\'s waiting for you on the <strong>SOZYN Jobseeker Board</strong>.
        </p>
        <p style="font-family:\'Segoe UI\',Arial,sans-serif; font-size:15px; color:#33404d; line-height:1.6;">
            Once you register, you can:
        </p>
        <ul style="font-family:\'Segoe UI\',Arial,sans-serif; font-size:14px; color:#33404d; line-height:1.8;">
            <li>Search and apply to jobs via <strong>JobWay</strong></li>
            <li>Track your applications in one dashboard</li>
            <li>Respond to recruiters and manage requests via the Jobseeker Board</li>
        </ul>
        <div style="background:#f0f1fb; border-left:4px solid #6366f1; padding:16px 20px; border-radius:6px; margin:18px 0; font-family:\'Segoe UI\',Arial,sans-serif; font-size:14px; color:#33404d; line-height:1.7;">
            <strong>Pricing at a glance</strong><br>
            Free: create your profile, add education, skills, certifications and employment history<br>
            Premium: ₹99 one-time — profile visible to recruiters on WyND, verified badge, priority shortlisting
        </div>
        <p style="font-family:\'Segoe UI\',Arial,sans-serif; font-size:13px; color:#7d8896; line-height:1.6;">
            Full pricing details and terms are always available at sozyn.co.in.
        </p>
        ' . $btn('Register as a Jobseeker', 'https://sozyn.co.in/register?tab=jobseeker');
}

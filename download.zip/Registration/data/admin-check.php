<?php
require_once 'admin-auth.php';
header('Content-Type: application/json');
echo json_encode([
    'isAdmin' => sozyn_is_admin(),
    'username' => sozyn_is_admin() ? sozyn_admin_username() : null,
]);

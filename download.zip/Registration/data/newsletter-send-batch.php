<?php
// Admin-only. Sends one batch of the prepared newsletter, called repeatedly
// by newsletter.php's JS until every recipient has been processed. Batching
// keeps each request well under shared-hosting execution time limits.

require_once __DIR__ . '/json-errors.php';
require_once 'admin-auth.php';
sozyn_require_admin();

header('Content-Type: application/json');
require_once 'db_connection.php';
require_once 'mailer.php';
require_once 'newsletter-template.php';

const BATCH_SIZE = 12;

$pendingFile = __DIR__ . '/newsletter-pending.json';
if (!file_exists($pendingFile)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'No newsletter is prepared. Start again from the compose screen.']);
    exit;
}
$job = json_decode(file_get_contents($pendingFile), true);
if (!$job) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Prepared newsletter is corrupted. Start again.']);
    exit;
}

$offset = isset($_POST['offset']) ? max(0, (int)$_POST['offset']) : 0;
$isTest = !empty($_POST['test']);

if ($isTest) {
    // Send exactly one preview email to the logged-in admin's own inbox.
    $testEmail = trim($_POST['test_email'] ?? '');
    if (!filter_var($testEmail, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'error' => 'Enter a valid email to send the test to.']);
        exit;
    }
    try {
        $mail = sozyn_new_mailer();
        $mail->addAddress($testEmail);
        $mail->Subject = '[TEST] ' . $job['subject'];
        $mail->Body = sozyn_build_newsletter_html($job['body'], 'there', 'https://sozyn.co.in');
        $mail->send();
        echo json_encode(['success' => true, 'test_sent' => true]);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => 'Test send failed: ' . $e->getMessage()]);
    }
    exit;
}

$audience = $job['audience'];
$where = "WHERE status = 'active'";
if ($audience !== 'all') {
    $where .= " AND subscriber_type = '" . ($audience === 'jobseeker' ? 'jobseeker' : 'organization') . "'";
}

$total = (int)$conn->query("SELECT COUNT(*) AS c FROM subscribers $where")->fetch_assoc()['c'];

$result = $conn->query("SELECT full_name, email, unsubscribe_token FROM subscribers $where ORDER BY id ASC LIMIT $offset, " . BATCH_SIZE);

$sentThisBatch = 0;
$failedThisBatch = 0;

while ($row = $result->fetch_assoc()) {
    try {
        $mail = sozyn_new_mailer();
        $mail->addAddress($row['email'], $row['full_name']);
        $mail->Subject = $job['subject'];
        $unsubUrl = 'https://sozyn.co.in/unsubscribe?token=' . urlencode($row['unsubscribe_token']);
        $mail->Body = sozyn_build_newsletter_html($job['body'], $row['full_name'], $unsubUrl);
        $mail->send();
        $sentThisBatch++;
    } catch (Exception $e) {
        $failedThisBatch++;
    }
}

$newOffset = $offset + BATCH_SIZE;
$done = $newOffset >= $total;

// Track running totals across the whole job in the pending file itself.
$job['sent_so_far'] = ($job['sent_so_far'] ?? 0) + $sentThisBatch;
$job['failed_so_far'] = ($job['failed_so_far'] ?? 0) + $failedThisBatch;
file_put_contents($pendingFile, json_encode($job));

if ($done) {
    $logStmt = $conn->prepare(
        "INSERT INTO newsletter_log (subject, audience, total_sent, total_failed, admin_username)
         VALUES (?, ?, ?, ?, ?)"
    );
    $logStmt->bind_param(
        "ssiis",
        $job['subject'],
        $job['audience'],
        $job['sent_so_far'],
        $job['failed_so_far'],
        $job['admin_username']
    );
    $logStmt->execute();
    $logStmt->close();
    @unlink($pendingFile);
}

echo json_encode([
    'success' => true,
    'sent_this_batch' => $sentThisBatch,
    'failed_this_batch' => $failedThisBatch,
    'offset' => $newOffset,
    'total' => $total,
    'sent_so_far' => $job['sent_so_far'],
    'failed_so_far' => $job['failed_so_far'],
    'done' => $done,
]);

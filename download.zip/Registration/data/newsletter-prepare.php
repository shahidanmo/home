<?php
// Admin-only. Stores the composed newsletter (subject, HTML body, audience)
// in a temp file and reports how many recipients will receive it, before
// the browser starts the batch-send loop.

require_once __DIR__ . '/json-errors.php';
require_once 'admin-auth.php';
sozyn_require_admin();

header('Content-Type: application/json');
require_once 'db_connection.php';

$subject = trim($_POST['subject'] ?? '');
$body = $_POST['body'] ?? '';
$audience = trim($_POST['audience'] ?? 'all');

if ($subject === '' || trim($body) === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Subject and newsletter content are required.']);
    exit;
}
if (!in_array($audience, ['all', 'jobseeker', 'organization'], true)) {
    $audience = 'all';
}

$where = "WHERE status = 'active'";
if ($audience !== 'all') {
    $where .= " AND subscriber_type = '" . ($audience === 'jobseeker' ? 'jobseeker' : 'organization') . "'";
}
$countRes = $conn->query("SELECT COUNT(*) AS c FROM subscribers $where");
if (!$countRes) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Database error: ' . $conn->error . ' (has subscribers_schema.sql been run?)']);
    exit;
}
$count = $countRes->fetch_assoc()['c'];

$job = [
    'subject' => $subject,
    'body' => $body,
    'audience' => $audience,
    'admin_username' => sozyn_admin_username(),
    'created_at' => date('c'),
];
if (file_put_contents(__DIR__ . '/newsletter-pending.json', json_encode($job)) === false) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Could not write newsletter-pending.json. Make Registration/data/ writable (755, or 777 if needed).']);
    exit;
}

echo json_encode(['success' => true, 'total' => (int)$count]);

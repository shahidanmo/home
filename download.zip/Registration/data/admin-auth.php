<?php
// Shared admin-session helper for the live content editor.
// Include this at the top of any endpoint that should only work for a
// logged-in site admin.

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => true,     // requires HTTPS (sozyn.co.in already is)
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

function sozyn_is_admin(): bool
{
    return !empty($_SESSION['sozyn_admin']) && !empty($_SESSION['sozyn_admin_username']);
}

function sozyn_require_admin(): void
{
    if (!sozyn_is_admin()) {
        http_response_code(401);
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'Not authenticated.']);
        exit;
    }
}

function sozyn_admin_username(): ?string
{
    return $_SESSION['sozyn_admin_username'] ?? null;
}

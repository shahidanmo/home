<?php
require_once 'data/db_connection.php';
require_once 'data/admin-auth.php';
sozyn_require_admin();

$rows = $conn->query(
    "SELECT id, full_name, email, subscriber_type, designation, created_at
     FROM subscribers WHERE welcome_sent = 0 AND status = 'active'
     ORDER BY created_at ASC"
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>New Subscribers — SOZYN Admin</title>
<style>
body { font-family: -apple-system, Segoe UI, Arial, sans-serif; background:#f5f6f8; margin:0; color:#26313d; }
.topbar { background:#1c2430; color:#fff; padding:16px 24px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px; }
.topbar a { color:#aab3c0; text-decoration:none; margin-left:16px; font-size:.85rem; }
.wrap { max-width:1000px; margin:24px auto; padding:0 20px 60px; }
.card { background:#fff; border-radius:12px; padding:20px; box-shadow:0 4px 14px rgba(0,0,0,.05); margin-bottom:18px; }
table { width:100%; border-collapse:collapse; }
th, td { padding:10px 12px; text-align:left; font-size:.85rem; border-bottom:1px solid #eee; }
th { background:#f0f1f5; }
.badge { padding:3px 9px; border-radius:20px; font-size:.72rem; font-weight:700; background:#eef0ff; color:#4548c9; }
button { border:none; border-radius:7px; padding:10px 16px; font-weight:700; font-size:.85rem; cursor:pointer; }
.btn-primary { background:#6366f1; color:#fff; }
.btn-secondary { background:#eef0f4; color:#333; }
.actions-bar { display:flex; gap:10px; margin-top:14px; flex-wrap:wrap; align-items:center; }
.empty { text-align:center; color:#888; padding:50px; }
#progressWrap { display:none; margin-top:14px; }
.bar-outer { background:#eef0f4; border-radius:20px; height:12px; overflow:hidden; }
.bar-inner { background:#22c55e; height:100%; width:0%; transition:width .2s; }
#progressText { font-size:.8rem; color:#555; margin-top:6px; }
</style>
</head>
<body>
<div class="topbar">
    <div>SOZYN Admin — New Subscribers</div>
    <div>
        <a href="/Registration/Admin.php">Console</a>
        <a href="/Registration/subscribers.php">All Subscribers</a>
        <a href="/Registration/Admin.php?logout=1">Log out</a>
    </div>
</div>
<div class="wrap">
    <div class="card">
        <p style="margin-top:0; color:#555; font-size:.88rem;">
            Everyone below has subscribed but hasn't received the
            "Thanks for subscribing to SOZYN Newsletter" letter yet. Pick who
            to send it to, or send it to everyone at once. Once sent, a
            subscriber drops off this list automatically.
        </p>

        <?php if ($rows->num_rows === 0): ?>
            <div class="empty">No pending subscribers right now — you're all caught up.</div>
        <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th style="width:30px;"><input type="checkbox" id="selectAll"></th>
                    <th>Name</th><th>Email</th><th>Type</th><th>Designation</th><th>Subscribed</th>
                </tr>
            </thead>
            <tbody>
            <?php while ($r = $rows->fetch_assoc()): ?>
                <tr>
                    <td><input type="checkbox" class="rowCheck" value="<?= (int)$r['id'] ?>"></td>
                    <td><?= htmlspecialchars($r['full_name']) ?></td>
                    <td><?= htmlspecialchars($r['email']) ?></td>
                    <td><span class="badge"><?= htmlspecialchars(ucfirst($r['subscriber_type'])) ?></span></td>
                    <td><?= htmlspecialchars($r['designation'] ?: '—') ?></td>
                    <td><?= htmlspecialchars(date('d M Y', strtotime($r['created_at']))) ?></td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>

        <div class="actions-bar">
            <button class="btn-secondary" id="sendSelectedBtn">Send to Selected</button>
            <button class="btn-primary" id="sendAllBtn">Send to All Pending (<?= $rows->num_rows ?>)</button>
        </div>
        <div id="progressWrap">
            <div class="bar-outer"><div class="bar-inner" id="barInner"></div></div>
            <div id="progressText">Starting…</div>
        </div>
        <?php endif; ?>
    </div>
</div>

<script>
document.getElementById('selectAll')?.addEventListener('change', function(){
    document.querySelectorAll('.rowCheck').forEach(cb => cb.checked = this.checked);
});

async function postJson(url, payload){
    const res = await fetch(url, { method:'POST', credentials:'same-origin',
        headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
    const text = await res.text();
    try { return JSON.parse(text); }
    catch(e){
        const snippet = text.replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim().slice(0,180);
        throw new Error('Server sent a non-JSON reply (HTTP ' + res.status + '): ' + snippet);
    }
}

function sendIds(ids){
    if (!ids.length) { alert('Select at least one subscriber first.'); return; }
    const progressWrap = document.getElementById('progressWrap');
    const barInner = document.getElementById('barInner');
    const progressText = document.getElementById('progressText');
    progressWrap.style.display = 'block';
    progressText.textContent = 'Sending…';
    document.getElementById('sendSelectedBtn').disabled = true;
    document.getElementById('sendAllBtn').disabled = true;

    function next(offset){
        postJson('/Registration/data/welcome-send-batch.php', { ids, offset })
            .then(data => {
                if (!data.success) throw new Error(data.error || 'Send failed');
                const doneCount = Math.min(data.offset, data.total);
                const pct = Math.round(doneCount / data.total * 100);
                barInner.style.width = pct + '%';
                progressText.textContent = 'Sent ' + doneCount + ' of ' + data.total +
                    (data.failed_this_batch ? ' (some failures — check mail-errors.log)' : '') + '…';
                if (data.done) {
                    progressText.textContent = 'Done — processed ' + data.total + ' subscriber(s).';
                    setTimeout(() => window.location.reload(), 1800);
                } else {
                    next(data.offset);
                }
            })
            .catch(err => { progressText.textContent = 'Error: ' + err.message; });
    }
    next(0);
}

document.getElementById('sendSelectedBtn')?.addEventListener('click', () => {
    const ids = Array.from(document.querySelectorAll('.rowCheck:checked')).map(cb => parseInt(cb.value));
    sendIds(ids);
});
document.getElementById('sendAllBtn')?.addEventListener('click', () => {
    const ids = Array.from(document.querySelectorAll('.rowCheck')).map(cb => parseInt(cb.value));
    if (!confirm('Send the welcome letter to all ' + ids.length + ' pending subscriber(s)?')) return;
    sendIds(ids);
});
</script>
</body>
</html>

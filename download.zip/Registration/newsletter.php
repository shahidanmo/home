<?php
require_once 'data/db_connection.php';
require_once 'data/admin-auth.php';
sozyn_require_admin();

$recentLogs = $conn->query("SELECT subject, audience, total_sent, total_failed, sent_at FROM newsletter_log ORDER BY sent_at DESC LIMIT 8");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Send Newsletter — SOZYN Admin</title>
<style>
body { font-family: -apple-system, Segoe UI, Arial, sans-serif; background:#f5f6f8; margin:0; color:#26313d; }
.topbar { background:#1c2430; color:#fff; padding:16px 24px; display:flex; justify-content:space-between; align-items:center; }
.topbar a { color:#aab3c0; text-decoration:none; margin-left:16px; font-size:.85rem; }
.wrap { max-width:820px; margin:24px auto; padding:0 20px 60px; }
.card { background:#fff; border-radius:12px; padding:26px; box-shadow:0 4px 14px rgba(0,0,0,.05); margin-bottom:22px; }
label { display:block; font-size:.82rem; color:#555; margin:14px 0 6px; font-weight:600; }
input[type=text], select, textarea { width:100%; box-sizing:border-box; padding:10px 12px; border-radius:6px; border:1px solid #dde1e6; font-size:.9rem; font-family:inherit; }
textarea { min-height:220px; font-family: Consolas, monospace; font-size:.82rem; }
.hint { font-size:.78rem; color:#888; margin-top:4px; }
.row { display:flex; gap:14px; }
.row > div { flex:1; }
button { border:none; border-radius:6px; padding:11px 18px; font-weight:700; cursor:pointer; font-size:.88rem; }
.btn-primary { background:#6366f1; color:#fff; }
.btn-secondary { background:#eef0f4; color:#333; }
.actions { display:flex; gap:10px; margin-top:20px; flex-wrap:wrap; }
#progressWrap { display:none; margin-top:20px; }
.bar-outer { background:#eef0f4; border-radius:20px; height:14px; overflow:hidden; }
.bar-inner { background:#22c55e; height:100%; width:0%; transition:width .2s; }
#progressText { font-size:.82rem; color:#555; margin-top:8px; }
table { width:100%; border-collapse:collapse; font-size:.85rem; }
th, td { padding:8px 10px; border-bottom:1px solid #eee; text-align:left; }
.file-drop { border:2px dashed #dde1e6; border-radius:8px; padding:16px; text-align:center; color:#888; font-size:.85rem; margin-top:6px; cursor:pointer; }
</style>
</head>
<body>
<div class="topbar">
    <div>SOZYN Admin — Send Newsletter</div>
    <div>
        <a href="/Registration/Admin.php">Console</a>
        <a href="/Registration/subscribers.php">Subscribers</a>
        <a href="/Registration/Admin.php?logout=1">Log out</a>
    </div>
</div>
<div class="wrap">
    <div class="card">
        <label>Subject line</label>
        <input type="text" id="subject" placeholder="e.g. New on SOZYN this month">

        <label>Send to</label>
        <select id="audience">
            <option value="all">Everyone (active subscribers)</option>
            <option value="jobseeker">Jobseekers only</option>
            <option value="organization">Organizations only</option>
        </select>

        <label>Newsletter HTML</label>
        <div class="file-drop" id="fileDrop">Click to upload an .html file, or just paste your HTML below</div>
        <input type="file" id="fileInput" accept=".html,.htm" style="display:none;">
        <textarea id="body" placeholder="<h2>Hello!</h2>&#10;<p>Your update goes here...</p>&#10;&#10;Tip: use {{name}} anywhere to insert the recipient's name."></textarea>
        <div class="hint">A greeting, SOZYN footer, and unsubscribe link are added automatically — you don't need to include those. Use <code>{{name}}</code> anywhere in your HTML for extra personalization.</div>

        <div class="row">
            <div>
                <label>Send yourself a test first</label>
                <input type="text" id="testEmail" placeholder="you@sozyn.co.in">
            </div>
        </div>

        <div class="actions">
            <button class="btn-secondary" id="sendTestBtn">Send test to me</button>
            <button class="btn-primary" id="sendAllBtn">Prepare &amp; Send to Subscribers</button>
        </div>

        <div id="progressWrap">
            <div class="bar-outer"><div class="bar-inner" id="barInner"></div></div>
            <div id="progressText">Starting…</div>
        </div>
    </div>

    <div class="card">
        <h3 style="margin-top:0;">Recent sends</h3>
        <table>
            <thead><tr><th>Subject</th><th>Audience</th><th>Sent</th><th>Failed</th><th>Date</th></tr></thead>
            <tbody>
            <?php if ($recentLogs->num_rows === 0): ?>
                <tr><td colspan="5" style="color:#888;">No newsletters sent yet.</td></tr>
            <?php else: while ($l = $recentLogs->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($l['subject']) ?></td>
                    <td><?= htmlspecialchars(ucfirst($l['audience'])) ?></td>
                    <td><?= (int)$l['total_sent'] ?></td>
                    <td><?= (int)$l['total_failed'] ?></td>
                    <td><?= htmlspecialchars(date('d M Y, H:i', strtotime($l['sent_at']))) ?></td>
                </tr>
            <?php endwhile; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
async function postForm(url, params) {
    const res = await fetch(url, { method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: params });
    const text = await res.text();
    try { return JSON.parse(text); }
    catch (e) {
        const snippet = text.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 180);
        throw new Error('Server sent a non-JSON reply (HTTP ' + res.status + ') from ' + url + ': ' + snippet);
    }
}
const fileDrop = document.getElementById('fileDrop');
const fileInput = document.getElementById('fileInput');
const bodyEl = document.getElementById('body');
fileDrop.addEventListener('click', () => fileInput.click());
fileInput.addEventListener('change', () => {
    const f = fileInput.files[0];
    if (!f) return;
    const reader = new FileReader();
    reader.onload = () => { bodyEl.value = reader.result; };
    reader.readAsText(f);
});

function getPayload() {
    return {
        subject: document.getElementById('subject').value.trim(),
        audience: document.getElementById('audience').value,
        body: bodyEl.value
    };
}

document.getElementById('sendTestBtn').addEventListener('click', function(){
    const payload = getPayload();
    const testEmail = document.getElementById('testEmail').value.trim();
    if (!payload.subject || !payload.body) { alert('Fill in a subject and newsletter content first.'); return; }
    if (!testEmail) { alert('Enter an email address to send the test to.'); return; }

    const btn = this;
    btn.disabled = true; btn.textContent = 'Sending test…';

    const form = new URLSearchParams({ subject: payload.subject, body: payload.body, audience: payload.audience });
    postForm('/Registration/data/newsletter-prepare.php', form)
    .then(p => { if (!p.success) throw new Error(p.error || 'Prepare failed'); })
    .then(() => postForm('/Registration/data/newsletter-send-batch.php', new URLSearchParams({ test: '1', test_email: testEmail })))
    .then(data => {
        alert(data.success ? 'Test email sent — check your inbox.' : ('Failed: ' + data.error));
    })
    .catch(err => alert('Test failed: ' + err.message))
    .finally(() => { btn.disabled = false; btn.textContent = 'Send test to me'; });
});

document.getElementById('sendAllBtn').addEventListener('click', function(){
    const payload = getPayload();
    if (!payload.subject || !payload.body) { alert('Fill in a subject and newsletter content first.'); return; }
    if (!confirm('This will send to your ' + document.getElementById('audience').selectedOptions[0].text + ' list. Continue?')) return;

    const btn = this;
    btn.disabled = true;
    const progressWrap = document.getElementById('progressWrap');
    const barInner = document.getElementById('barInner');
    const progressText = document.getElementById('progressText');
    progressWrap.style.display = 'block';
    progressText.textContent = 'Preparing…';

    const form = new URLSearchParams({ subject: payload.subject, body: payload.body, audience: payload.audience });
    postForm('/Registration/data/newsletter-prepare.php', form)
    .then(data => {
        if (!data.success) { throw new Error(data.error || 'Prepare failed'); }
        const total = data.total;
        if (total === 0) {
            progressText.textContent = 'No matching subscribers to send to.';
            btn.disabled = false;
            return;
        }
        sendNextBatch(0, total);
    })
    .catch(err => {
        progressText.textContent = 'Error: ' + err.message;
        btn.disabled = false;
    });

    function sendNextBatch(offset, total) {
        postForm('/Registration/data/newsletter-send-batch.php', new URLSearchParams({ offset: offset }))
        .then(data => {
            if (!data.success) { throw new Error(data.error || 'Send failed'); }
            const pct = Math.min(100, Math.round((data.sent_so_far + data.failed_so_far) / data.total * 100));
            barInner.style.width = pct + '%';
            progressText.textContent = 'Sent ' + data.sent_so_far + ' of ' + data.total +
                (data.failed_so_far ? (' (' + data.failed_so_far + ' failed)') : '') + '…';
            if (data.done) {
                progressText.textContent = 'Done — sent ' + data.sent_so_far + ' of ' + data.total +
                    (data.failed_so_far ? (', ' + data.failed_so_far + ' failed') : '') + '.';
                btn.disabled = false;
                setTimeout(() => window.location.reload(), 2500);
            } else {
                sendNextBatch(data.offset, data.total);
            }
        })
        .catch(err => {
            progressText.textContent = 'Error: ' + err.message;
            btn.disabled = false;
        });
    }
});
</script>
</body>
</html>

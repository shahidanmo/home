<?php
require_once 'data/db_connection.php';
require_once 'data/admin-auth.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'])) {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $conn->prepare("SELECT id, username, password_hash FROM admin_users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();

    if ($row && password_verify($password, $row['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['sozyn_admin'] = true;
        $_SESSION['sozyn_admin_username'] = $row['username'];
    } else {
        // Same generic message either way so a wrong username can't be
        // distinguished from a wrong password.
        $error = 'Invalid username or password.';
    }
}

if (isset($_GET['logout'])) {
    $_SESSION = [];
    session_destroy();
    header('Location: Admin.php');
    exit;
}

$loggedIn = sozyn_is_admin();
$pendingWelcomeCount = 0;
if ($loggedIn) {
    $res = $conn->query("SELECT COUNT(*) AS c FROM subscribers WHERE welcome_sent = 0 AND status = 'active'");
    if ($res) { $pendingWelcomeCount = (int)$res->fetch_assoc()['c']; }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>SOZYN Admin Console</title>
<style>
body { font-family: -apple-system, Segoe UI, Arial, sans-serif; background:#0f1720; color:#e6ebf1; display:flex; align-items:center; justify-content:center; min-height:100vh; margin:0; }
.card { background:#1c2430; padding:36px; border-radius:12px; width:100%; max-width:400px; box-shadow:0 20px 50px rgba(0,0,0,.4); }
h1 { font-size:1.3rem; margin-top:0; display:flex; align-items:center; gap:10px; }
label { display:block; margin:14px 0 6px; font-size:.85rem; color:#aab3c0; }
input { width:100%; box-sizing:border-box; padding:10px 12px; border-radius:6px; border:1px solid #333f4f; background:#0f1720; color:#fff; font-size:.95rem; }
button, .btn { margin-top:22px; width:100%; padding:12px; border:none; border-radius:6px; background:#6366f1; color:#fff; font-weight:600; cursor:pointer; font-size:.95rem; text-align:center; display:block; text-decoration:none; box-sizing:border-box; }
.error { background:#3a1f24; color:#ff9aa2; padding:10px 12px; border-radius:6px; font-size:.85rem; margin-top:14px; }
.muted { color:#aab3c0; font-size:.85rem; line-height:1.6; }
.logout { background:transparent; color:#aab3c0; text-decoration:underline; font-weight:400; margin-top:12px; }
.alert { background:#3a2f1a; border:1px solid #6b5322; color:#f5c96b; padding:12px 14px; border-radius:8px; font-size:.85rem; margin-top:0; margin-bottom:6px; display:flex; justify-content:space-between; align-items:center; gap:10px; }
.alert a { color:#fff; background:#6366f1; padding:6px 12px; border-radius:6px; text-decoration:none; font-weight:700; font-size:.8rem; white-space:nowrap; }
</style>
</head>
<body>
<div class="card">
<?php if ($loggedIn): ?>
    <h1>👋 Hi, <?= htmlspecialchars(sozyn_admin_username()) ?></h1>
    <?php if ($pendingWelcomeCount > 0): ?>
        <div class="alert">
            🔔 <?= $pendingWelcomeCount ?> new subscriber<?= $pendingWelcomeCount === 1 ? '' : 's' ?> haven't received a welcome letter yet.
            <a href="/Registration/welcome-subscribers.php">Review &amp; Send</a>
        </div>
    <?php endif; ?>
    <p class="muted">You're logged in as a site admin. Open the homepage and you'll see an <strong>Edit Page</strong> button in the bottom-right corner — click it to edit text, images, and button links directly on the live page.</p>
    <a class="btn" href="/">Go to homepage</a>
    <a class="btn" href="/Registration/subscribers.php" style="background:#26313d;">Manage Subscribers</a>
    <a class="btn" href="/Registration/welcome-subscribers.php" style="background:#26313d;">New Subscribers / Welcome Letters</a>
    <a class="btn" href="/Registration/newsletter.php" style="background:#26313d;">Send Newsletter</a>
    <a class="btn logout" href="/Registration/Admin.php?logout=1">Log out</a>
<?php else: ?>
    <h1>🔒 SOZYN Admin Console</h1>
    <form method="POST">
        <label>Username</label>
        <input type="text" name="username" required autofocus>
        <label>Password</label>
        <input type="password" name="password" required>
        <?php if ($error): ?><div class="error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
        <button type="submit">Log in</button>
    </form>
<?php endif; ?>
</div>
</body>
</html>

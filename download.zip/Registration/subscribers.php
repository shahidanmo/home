<?php
require_once 'data/db_connection.php';
require_once 'data/admin-auth.php';
sozyn_require_admin();

$filter = $_GET['filter'] ?? 'all';
$where = '';
if ($filter === 'active') { $where = "WHERE status = 'active'"; }
elseif ($filter === 'unsubscribed') { $where = "WHERE status = 'unsubscribed'"; }
elseif ($filter === 'jobseeker') { $where = "WHERE subscriber_type = 'jobseeker'"; }
elseif ($filter === 'organization') { $where = "WHERE subscriber_type = 'organization'"; }

$rows = $conn->query("SELECT id, full_name, email, gender, subscriber_type, designation, status, welcome_sent, created_at FROM subscribers $where ORDER BY created_at DESC");

$counts = $conn->query(
    "SELECT
        SUM(status='active') AS active_count,
        SUM(status='unsubscribed') AS unsub_count,
        SUM(subscriber_type='jobseeker') AS jobseeker_count,
        SUM(subscriber_type='organization') AS org_count,
        COUNT(*) AS total
     FROM subscribers"
)->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Subscribers — SOZYN Admin</title>
<style>
body { font-family: -apple-system, Segoe UI, Arial, sans-serif; background:#f5f6f8; margin:0; color:#26313d; }
.topbar { background:#1c2430; color:#fff; padding:16px 24px; display:flex; justify-content:space-between; align-items:center; }
.topbar a { color:#aab3c0; text-decoration:none; margin-left:16px; font-size:.85rem; }
.wrap { max-width:1100px; margin:24px auto; padding:0 20px; }
.stats { display:flex; gap:14px; flex-wrap:wrap; margin-bottom:20px; }
.stat { background:#fff; border-radius:10px; padding:14px 20px; box-shadow:0 4px 14px rgba(0,0,0,.05); min-width:120px; }
.stat b { display:block; font-size:1.4rem; }
.filters { margin-bottom:14px; }
.filters a { margin-right:14px; font-size:.85rem; color:#555; text-decoration:none; }
.filters a.active { color:#6366f1; font-weight:700; }
table { width:100%; border-collapse:collapse; background:#fff; border-radius:10px; overflow:hidden; box-shadow:0 4px 14px rgba(0,0,0,.05); }
th, td { padding:10px 14px; text-align:left; font-size:.85rem; border-bottom:1px solid #eee; }
th { background:#f0f1f5; }
.badge { padding:3px 9px; border-radius:20px; font-size:.72rem; font-weight:700; }
.badge.active { background:#e3fbe9; color:#1c8a3b; }
.badge.unsubscribed { background:#fdeaea; color:#c23636; }
.actions button { border:none; border-radius:5px; padding:5px 10px; font-size:.75rem; cursor:pointer; margin-right:4px; }
.btn-del { background:#fdeaea; color:#c23636; }
.btn-unsub { background:#fff4de; color:#a06a00; }
.btn-resub { background:#e3fbe9; color:#1c8a3b; }
.empty { text-align:center; color:#888; padding:40px; }
</style>
</head>
<body>
<div class="topbar">
    <div>SOZYN Admin — Subscribers</div>
    <div>
        <a href="/Registration/Admin.php">Console</a>
        <a href="/Registration/newsletter.php">Send Newsletter</a>
        <a href="/Registration/Admin.php?logout=1">Log out</a>
    </div>
</div>
<div class="wrap">
    <div class="stats">
        <div class="stat"><b><?= (int)$counts['total'] ?></b>Total</div>
        <div class="stat"><b><?= (int)$counts['active_count'] ?></b>Active</div>
        <div class="stat"><b><?= (int)$counts['unsub_count'] ?></b>Unsubscribed</div>
        <div class="stat"><b><?= (int)$counts['jobseeker_count'] ?></b>Jobseekers</div>
        <div class="stat"><b><?= (int)$counts['org_count'] ?></b>Organizations</div>
    </div>
    <div class="filters">
        <a href="?filter=all" class="<?= $filter==='all'?'active':'' ?>">All</a>
        <a href="?filter=active" class="<?= $filter==='active'?'active':'' ?>">Active</a>
        <a href="?filter=unsubscribed" class="<?= $filter==='unsubscribed'?'active':'' ?>">Unsubscribed</a>
        <a href="?filter=jobseeker" class="<?= $filter==='jobseeker'?'active':'' ?>">Jobseekers</a>
        <a href="?filter=organization" class="<?= $filter==='organization'?'active':'' ?>">Organizations</a>
    </div>
    <table>
        <thead>
            <tr><th>Name</th><th>Email</th><th>Type</th><th>Designation</th><th>Gender</th><th>Status</th><th>Welcome</th><th>Joined</th><th>Actions</th></tr>
        </thead>
        <tbody id="subRows">
        <?php if ($rows->num_rows === 0): ?>
            <tr><td colspan="9" class="empty">No subscribers match this filter yet.</td></tr>
        <?php else: while ($r = $rows->fetch_assoc()): ?>
            <tr data-row-id="<?= (int)$r['id'] ?>">
                <td><?= htmlspecialchars($r['full_name']) ?></td>
                <td><?= htmlspecialchars($r['email']) ?></td>
                <td><?= htmlspecialchars(ucfirst($r['subscriber_type'])) ?></td>
                <td><?= htmlspecialchars($r['designation'] ?: '—') ?></td>
                <td><?= htmlspecialchars(str_replace('_',' ', $r['gender'])) ?></td>
                <td><span class="badge <?= $r['status'] ?>"><?= $r['status'] ?></span></td>
                <td><?= $r['welcome_sent'] ? '✅ Sent' : '⏳ Pending' ?></td>
                <td><?= htmlspecialchars(date('d M Y', strtotime($r['created_at']))) ?></td>
                <td class="actions">
                    <?php if ($r['status'] === 'active'): ?>
                        <button class="btn-unsub" onclick="doAction(<?= (int)$r['id'] ?>,'unsubscribe',this)">Unsubscribe</button>
                    <?php else: ?>
                        <button class="btn-resub" onclick="doAction(<?= (int)$r['id'] ?>,'resubscribe',this)">Resubscribe</button>
                    <?php endif; ?>
                    <button class="btn-del" onclick="doAction(<?= (int)$r['id'] ?>,'delete',this)">Delete</button>
                </td>
            </tr>
        <?php endwhile; endif; ?>
        </tbody>
    </table>
</div>
<script>
function doAction(id, action, btn) {
    if (action === 'delete' && !confirm('Delete this subscriber permanently?')) return;
    btn.disabled = true;
    fetch('/Registration/data/subscriber-action.php', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'id=' + encodeURIComponent(id) + '&action=' + encodeURIComponent(action)
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) { window.location.reload(); }
        else { alert('Action failed.'); btn.disabled = false; }
    })
    .catch(() => { alert('Network error.'); btn.disabled = false; });
}
</script>
</body>
</html>

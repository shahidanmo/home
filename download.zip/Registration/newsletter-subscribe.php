<?php
// Public. Handles the "Subscribe to Newsletter" popup submission.

header('Content-Type: application/json');
require_once 'db_connection.php';
require_once 'mailer.php';
require_once 'newsletter-template.php';
require_once 'welcome-email.php';

function sozyn_send_welcome(string $email, string $fullName, string $subscriberType, string $token): void
{
    try {
        $mail = sozyn_new_mailer();
        $mail->addAddress($email, $fullName);
        $mail->Subject = sozyn_welcome_subject($subscriberType);
        $unsubUrl = 'https://sozyn.co.in/unsubscribe?token=' . urlencode($token);
        $mail->Body = sozyn_build_newsletter_html(sozyn_welcome_body_html($subscriberType), $fullName, $unsubUrl);
        $mail->send();
    } catch (Exception $e) {
        // Never let a mail failure block the subscribe response — the
        // subscription itself already succeeded in the database.
    }
}

function respond(bool $success, string $message): void
{
    echo json_encode(['success' => $success, 'message' => $message]);
    exit;
}

$fullName = trim($_POST['full_name'] ?? '');
$email = trim($_POST['email'] ?? '');
$gender = trim($_POST['gender'] ?? 'prefer_not_to_say');
$subscriberType = trim($_POST['subscriber_type'] ?? '');
$designation = trim($_POST['designation'] ?? '');

if ($fullName === '' || $email === '' || $subscriberType === '') {
    respond(false, 'Please fill in your name, email, and whether you are a jobseeker or organization.');
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    respond(false, 'That doesn\'t look like a valid email address.');
}
$allowedGenders = ['male', 'female', 'other', 'prefer_not_to_say'];
if (!in_array($gender, $allowedGenders, true)) { $gender = 'prefer_not_to_say'; }
if (!in_array($subscriberType, ['jobseeker', 'organization'], true)) {
    respond(false, 'Please select Jobseeker or Organization.');
}
if (strlen($fullName) > 150) { $fullName = substr($fullName, 0, 150); }
if (strlen($designation) > 150) { $designation = substr($designation, 0, 150); }

$stmt = $conn->prepare("SELECT id, status, unsubscribe_token FROM subscribers WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$existing = $stmt->get_result()->fetch_assoc();
$stmt->close();

if ($existing) {
    if ($existing['status'] === 'active') {
        respond(false, 'This email is already subscribed.');
    }
    // Previously unsubscribed — treat a fresh signup as a resubscribe and
    // refresh their details.
    $update = $conn->prepare(
        "UPDATE subscribers SET full_name=?, gender=?, subscriber_type=?, designation=?, status='active'
         WHERE id=?"
    );
    $update->bind_param("ssssi", $fullName, $gender, $subscriberType, $designation, $existing['id']);
    $update->execute();
    $update->close();
    sozyn_send_welcome($email, $fullName, $subscriberType, $existing['unsubscribe_token']);
    respond(true, 'Welcome back! You are subscribed again.');
}

$token = bin2hex(random_bytes(24));
$insert = $conn->prepare(
    "INSERT INTO subscribers (full_name, email, gender, subscriber_type, designation, unsubscribe_token)
     VALUES (?, ?, ?, ?, ?, ?)"
);
$insert->bind_param("ssssss", $fullName, $email, $gender, $subscriberType, $designation, $token);

if ($insert->execute()) {
    sozyn_send_welcome($email, $fullName, $subscriberType, $token);
    respond(true, 'Thanks for subscribing!');
} else {
    respond(false, 'Something went wrong. Please try again.');
}

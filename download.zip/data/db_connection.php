<?php
$host = "sql112.infinityfree.com";
$user = "if0_42299495";
$pass = "Sh1hid786";
$dbname = "if0_42299495_sozyn";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>